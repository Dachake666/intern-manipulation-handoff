"""
PyPilotSDK - Python bindings for YouiPilotSDK (Python 3.10 compatible, x86_64)
"""
__version__ = "1.0.0422.1"
import os
import sys

def _ensure_dependencies_loaded():
    """确保依赖库已正确加载"""
    try:
        # 首先导入并执行依赖库预加载
        from . import _load_deps
        # 检查预加载是否成功
        if hasattr(_load_deps, '_preload_success'):
            if not _load_deps._preload_success:
                print("警告: 依赖库预加载可能失败")
        return True
    except ImportError as e:
        print(f"警告: 无法导入依赖库加载器: {e}")

        # 备用方案：手动设置路径
        module_dir = os.path.dirname(os.path.abspath(__file__))
        libs_dir = os.path.join(module_dir, '.libs')

        if os.path.exists(libs_dir):
            # 尝试使用ctypes直接加载libyouizmq.so
            try:
                import ctypes
                import glob

                # 查找libyouizmq.so
                libyouizmq_path = os.path.join(libs_dir, 'libyouizmq.so')
                if os.path.exists(libyouizmq_path):
                    ctypes.CDLL(libyouizmq_path, mode=ctypes.RTLD_GLOBAL)
                    print(f"✓ 手动预加载: libyouizmq.so")
                else:
                    # 使用通配符查找
                    pattern = os.path.join(libs_dir, 'libyouizmq*.so')
                    matches = glob.glob(pattern)
                    if matches:
                        ctypes.CDLL(matches[0], mode=ctypes.RTLD_GLOBAL)
                        print(f"✓ 手动预加载: {os.path.basename(matches[0])}")

                # 设置LD_LIBRARY_PATH
                if 'LD_LIBRARY_PATH' in os.environ:
                    os.environ['LD_LIBRARY_PATH'] = libs_dir + ':' + os.environ['LD_LIBRARY_PATH']
                else:
                    os.environ['LD_LIBRARY_PATH'] = libs_dir

            except Exception as load_error:
                print(f"手动加载依赖库失败: {load_error}")
                return False

        return True

# 在导入主模块之前确保依赖已加载
if not _ensure_dependencies_loaded():
    print("错误: 依赖库加载失败")
    sys.exit(1)

# 导入主模块
try:
    from .pypilot import *
    # 显式导入所有类型以帮助IDE自动补全
    from .pypilot import (
        PilotSDK,
        # 基础数据类型
        Point2D, Point3D, Position, Velocity, VelocityData,
        BatteryInfo, LoadInfo, LoadDimensions, E84Info,
        ButtonStatus, MapInfo, ActionState, StorageInfo,
        StorageDoorInfo, NfcRingInfo, Parameter, QrInfo,
        AgvInfo, ComputerInfo, ErrorInfo, RasterInfo,
        FFUInfo, DustParticleDetectorInfo,
        # 传感器数据类型
        CameraData, ImuData, LidarData, LaserData2D,
        OdomData, CurrentPoseData, QrData, ManualControlAction,
        # 容器类型
        IntVector, FloatVector, DoubleVector, StringVector,
        BoolVector, StringMap, BatteryInfoVector, Point3DVector,
        # 机械臂相关
        ArmBindMode, AxisParameterIndex, LoadParameter,
        RobotWorldsData, RobotWorldsDataVector,
        Int32Vector, IntDoubleVectorMap,
        MoveJointsEndData, MoveWorldsEndData
    )
except ImportError as import_error:
    if "libyouizmq.so" in str(import_error):
        print("错误: libyouizmq.so 无法加载")
        print("这可能是由于系统兼容性问题，请尝试：")
        print("1. 重新安装包: pip uninstall pypilot && pip install pypilot")
        print("2. 检查系统架构是否为 x86_64 Linux")
        print("3. 手动设置 LD_LIBRARY_PATH 环境变量")
    else:
        print(f"导入pypilot模块失败: {import_error}")
    raise

# 工厂函数
def create_sdk() -> PilotSDK:
    """创建并返回一个PilotSDK实例."""
    return PilotSDK()

# 导出主要类和函数
__all__ = [
    # 主SDK类和工厂函数
    'PilotSDK', 'create_sdk',
    # 基础数据类型
    'Point2D', 'Point3D', 'Position', 'Velocity', 'VelocityData',
    'BatteryInfo', 'LoadInfo', 'LoadDimensions', 'E84Info',
    'ButtonStatus', 'MapInfo', 'ActionState', 'StorageInfo',
    'StorageDoorInfo', 'NfcRingInfo', 'Parameter', 'QrInfo',
    'AgvInfo', 'ComputerInfo', 'ErrorInfo', 'RasterInfo',
    'FFUInfo', 'DustParticleDetectorInfo',
    # 传感器数据类型
    'CameraData', 'ImuData', 'LidarData', 'LaserData2D',
    'OdomData', 'CurrentPoseData', 'QrData', 'ManualControlAction',
    # 容器类型
    'IntVector', 'FloatVector', 'DoubleVector', 'StringVector',
    'BoolVector', 'StringMap', 'BatteryInfoVector', 'Point3DVector',
    # 机械臂相关
    'ArmBindMode', 'AxisParameterIndex', 'LoadParameter',
    'RobotWorldsData', 'RobotWorldsDataVector',
    'Int32Vector', 'IntDoubleVectorMap',
    'MoveJointsEndData', 'MoveWorldsEndData'
]
