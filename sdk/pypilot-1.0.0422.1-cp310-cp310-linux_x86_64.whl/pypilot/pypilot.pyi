"""
Type stubs for pypilot module - YouiPilot SDK Python Wrapper

This module provides Python bindings for the YouiPilot robot control SDK,
enabling Python applications to interact with AGV robots through
a C++ interface using Boost.Python.

Generated from C++ headers for IDE support and type checking.
"""

from typing import List, Tuple, Callable, Union, Dict, Any, Optional
import builtins

# Type aliases for better readability
FloatVector = List[float]
DoubleVector = List[float]
IntVector = List[int]
StringVector = List[str]
BoolVector = List[bool]
StringMap = Dict[str, str]

# Callback function type definitions
ImuCallback = Callable[['ImuData'], None]  # (imu_data) -> None
OdomCallback = Callable[['OdomData'], None]  # (odom_data) -> None
VelocityCallback = Callable[['VelocityData'], None]  # (velocity_data) -> None
CurrentPoseCallback = Callable[['CurrentPoseData'], None]  # (current_pose_data) -> None
QrDataCallback = Callable[['QrData'], None]  # (qr_data) -> None
CameraCallback = Callable[['CameraData'], None]  # (camera_data) -> None
LidarCallback = Callable[['LidarData'], None]  # (lidar_data) -> None

# Mechanical arm callback function type definitions
MoveJointsEndCallback = Callable[[int, bool], None]  # (robot_id, end) -> None
MoveWorldsEndCallback = Callable[[int, bool], None]  # (robot_id, end) -> None

# ================== Data Structure Classes ==================

class Position:
    """AGV position information structure."""
    status: str  # 定位状态 (NOT_LOCATED/LOCATED)
    localizationScore: int  # 定位质量 (0-3)
    x: float  # X坐标
    y: float  # Y坐标
    theta: float  # 角度（弧度）
    located: bool  # 是否已定位

class Velocity:
    """AGV velocity information structure."""
    vx: float  # X方向速度 (米/秒)
    vy: float  # Y方向速度 (米/秒)
    omega: float  # 绕Z轴转动速度 (弧度/秒)

class MapInfo:
    """Map information structure."""
    mapId: str  # 地图编号
    locationMapId: str  # 定位图编号
    mapVersion: str  # 地图版本
    mapDescription: str  # 地图描述

class ActionState:
    """Action state structure."""
    actionId: str  # 动作唯一标识符
    actionType: str  # 动作类型
    actionDescription: str  # 动作描述
    actionStatus: str  # 动作状态 (WAITING/INITIALIZING/RUNNING/PAUSED/FINISHED/FAILED/CANCELLED)
    actionResult: Dict[str, Any]  # 动作执行结果

class ManualControlAction:
    """Manual control action state structure."""
    actionId: str  # 动作的唯一标识符
    actionType: str  # 动作类型
    actionDescription: str  # 当前动作的附加信息
    actionStatus: str  # 动作状态描述

class BatteryInfo:
    """Battery information structure."""
    batteryId: str  # 电池ID，电池序列号
    batteryLevel: float  # 当前电量 (%)
    batteryVoltage: float  # 电池电压 (V)
    batteryCharge: float  # 电池充电电流 (A)
    batteryDischarge: float  # 电池放电电流 (A)
    chargingTimes: int  # 电池充放电次数
    batteryHealth: int  # 电池健康状态 (0-100)
    batteryCellTemperatures: IntVector  # 电池电芯温度
    batteryMosfetTemperatures: IntVector  # 电池mosfet温度
    vcells: IntVector  # 电池电芯电压
    charging: bool  # 是否正在充电

class LoadInfo:
    """Load information structure."""
    loadId: str  # 负载的唯一标识（例如条形码或RFID）
    loadType: str  # 负载类型
    loadPosition: str  # 负载位置（例如：front/back/positionC1）
    weight: float  # 负载的绝对重量 (千克)
    loadDimensions: 'LoadInfo.LoadDimensions'  # 负载边界框的尺寸

    class LoadDimensions:
        """Load dimensions structure."""
        length: float  # 负载边界框的绝对长度 (米)
        width: float   # 负载边界框的绝对宽度 (米)
        height: float  # 负载边界框的绝对高度 (米)

# LoadDimensions 作为顶级类型别名导出
LoadDimensions = LoadInfo.LoadDimensions

class StorageInfo:
    """Storage status structure."""
    storageId: str  # 储位id (改为string类型)
    storageStatus: str  # 储位状态 (DISABLE/EMPTY/FULL/OFFSET/ERROR)
    carrierPosition: int  # 载位位置 (-1:未知, 1:载位1, 2:载位2, 3:载位3)
    code: str  # 物料编码
    lockStatus: str  # 储位锁状态 (OPEN/CLOSE)
    photoSensor: bool  # 光电传感器状态
    pressSensor: BoolVector  # 按压传感器状态

class E84Info:
    """E84 status structure."""
    status: IntVector  # E84状态（ok：[0]，error：异常码组）
    versionNumber: str  # 版本号显示
    inputIO: IntVector  # E84输入I/O状态
    outputIO: IntVector  # E84输出I/O状态
    config: str  # E84配置

class ButtonStatus:
    """Button status structure."""
    powerButton: int  # 底盘开关机按钮触发状态
    resetButton: int  # 复位按钮触发状态

class StorageDoorInfo:
    """Storage door status structure."""
    storageDoorId: str  # 储位门id (改为string类型)
    status: str  # 储位门状态 (OPEN/CLOSE/ERROR) - 改为全大写
    relative: IntVector  # 关联的储位数组

class NfcRingInfo:
    """NFC ring information structure."""
    status: str  # NFC状态 (OPEN/CLOSE/ERROR) - 改为全大写
    cardType: str  # 监听到的手环类型
    cardId: str  # 监听到的手环id

class ErrorInfo:
    """Error information structure."""
    errorCode: str  # 错误编码
    errorDescription: str  # 详细描述
    errorHint: str  # 解决提示
    errorLevel: str  # 报警等级 (WARNING/FATAL)

class RasterInfo:
    """Raster/Grating status structure."""
    num: int  # 光栅数量（0-3）
    gratingId: str  # 光栅id (改为string类型，字段名改为gratingId)
    status: str  # 光栅状态 (TRIGGER/NOT_TRIGGER/CLOSE/ERROR) - 改为全大写
    relative: IntVector  # 关联的储位数组

class FFUInfo:
    """FFU status structure."""
    status: str  # FFU状态 (OPEN/CLOSE/ERROR) - 改为全大写
    usetime: int  # FFU运行时长 (秒)
    lifetime: int  # FFU总寿命 (秒)
    windSpeed: float  # FFU风速 (米/秒)

class DustParticleDetectorInfo:
    """Dust particle detector information structure."""
    status: str  # 尘埃粒子检测仪状态 (OPEN/CLOSE/ERROR) - 改为全大写
    particlesNum: float  # 粒子数/立方米

class Parameter:
    """Extended parameter structure."""
    key: str  # 扩展参数名称
    value: str  # 与键对应的值

class QrInfo:
    """QR code information structure."""
    qrId: int  # 二维码ID
    x: float  # X坐标
    y: float  # Y坐标
    theta: float  # 角度

class AgvInfo:
    """AGV basic information structure."""
    agvId: str  # AGV ID
    seriesName: str  # 系列名称
    serialNumber: str  # 序列号
    versions: Dict[str, str]  # 版本信息字典

class ComputerInfo:
    """Computer information structure."""
    cpu_ocp: float  # CPU占用率
    mem_ocp: float  # 内存占用率
    space_free: float  # 剩余磁盘空间
    temperature: float  # 温度
    space_total: float  # 总磁盘空间
    mem_total: float  # 总内存
    harddisk_life: int  # 硬盘寿命
    CPU: str  # CPU信息
    system: str  # 系统信息

class Point2D:
    """2D point structure."""
    x: float
    y: float

class Point3D:
    """3D point structure."""
    x: float
    y: float
    z: float

class LaserData2D:
    """2D laser scan data structure."""
    points: List[Point2D]  # 点云数据

# ================== ZMQ Data Structures ==================

class LidarData:
    """Lidar data structure."""
    lidar_id: int  # 激光雷达ID
    seq: int  # 序列号
    timestamp_sec: int  # 时间戳秒
    timestamp_nsec: int  # 时间戳纳秒
    frame_id: str  # 坐标系ID
    angle_min: float  # 最小角度
    angle_max: float  # 最大角度
    angle_increment: float  # 角度增量
    time_increment: float  # 时间增量
    scan_time: float  # 扫描时间
    range_min: float  # 最小距离
    range_max: float  # 最大距离
    max_count: int  # 最大点数
    range_count: int  # 实际距离点数
    intensity_count: int  # 实际强度点数
    ranges: FloatVector  # 距离数组
    intensities: FloatVector  # 强度数组

class ImuData:
    """IMU data structure."""
    seq: int  # 序列号
    timestamp_sec: int  # 时间戳秒
    timestamp_nsec: int  # 时间戳纳秒
    frame_id: str  # 坐标系ID
    orientation_x: float  # 四元数x
    orientation_y: float  # 四元数y
    orientation_z: float  # 四元数z
    orientation_w: float  # 四元数w
    orientation_covariance: DoubleVector  # 方向协方差矩阵 (9 elements)
    angular_vel_x: float  # 角速度x
    angular_vel_y: float  # 角速度y
    angular_vel_z: float  # 角速度z
    angular_velocity_covariance: DoubleVector  # 角速度协方差矩阵 (9 elements)
    linear_acc_x: float  # 线性加速度x
    linear_acc_y: float  # 线性加速度y
    linear_acc_z: float  # 线性加速度z
    linear_acc_covariance: DoubleVector  # 线性加速度协方差矩阵 (9 elements)

class OdomData:
    """Odometry data structure."""
    seq: int  # 序列号
    timestamp_sec: int  # 时间戳秒
    timestamp_nsec: int  # 时间戳纳秒
    frame_id: str  # 坐标系ID
    child_frame_id: str  # 子坐标系ID
    pos_x: float  # x位置
    pos_y: float  # y位置
    pos_z: float  # z位置
    ori_x: float  # 四元数x
    ori_y: float  # 四元数y
    ori_z: float  # 四元数z
    ori_w: float  # 四元数w
    linear_x: float  # 线速度x
    linear_y: float  # 线速度y
    linear_z: float  # 线速度z
    angular_x: float  # 角速度x
    angular_y: float  # 角速度y
    angular_z: float  # 角速度z
    pose_covariance: DoubleVector  # 位置协方差矩阵 (36 elements)
    twist_covariance: DoubleVector  # 扭曲协方差矩阵 (36 elements)

class VelocityData:
    """Velocity data structure."""
    act_vel_x: float  # 实际速度x
    act_vel_y: float  # 实际速度y
    act_vel_w: float  # 实际角速度w

class CurrentPoseData:
    """Current pose data structure."""
    seq: int  # 序列号
    timestamp_sec: int  # 时间戳秒
    timestamp_nsec: int  # 时间戳纳秒
    frame_id: str  # 坐标系ID
    pos_x: float  # x位置
    pos_y: float  # y位置
    pos_angle: float  # 角度
    pos_current_station: str  # 当前站点

class QrData:
    """QR code data structure."""
    seq: int  # 序列号
    timestamp_sec: int  # 时间戳秒
    timestamp_nsec: int  # 时间戳纳秒
    frame_id: str  # 坐标系ID
    signatures: StringVector  # 签名列表
    x: float  # x坐标
    y: float  # y坐标
    theta: float  # 角度

class CameraData:
    """Camera data structure."""
    seq: int  # 序列号
    timestamp_sec: int  # 时间戳秒
    timestamp_nsec: int  # 时间戳纳秒
    frame_id: str  # 坐标系ID
    points: Point3DVector  # 点云数据

# ================== 机械臂相关数据结构 ==================

class MoveJointsEndData:
    """关节运动结束回调数据结构."""
    robot_id: int  # 机器人ID
    end: bool  # 运动是否结束

class MoveWorldsEndData:
    """世界坐标运动结束回调数据结构."""
    robot_id: int  # 机器人ID
    end: bool  # 运动是否结束

class LoadParameter:
    """负载参数结构."""
    quality: float  # 质量
    center_mass_x: float  # 质心X
    center_mass_y: float  # 质心Y
    center_mass_z: float  # 质心Z

class RobotWorldsData:
    """机器人世界坐标数据结构."""
    robotId: int  # 机器人ID
    worldPos: FloatVector  # XYZUVW坐标
    needCallback: bool  # 是否需要回调

# 机械臂相关枚举
class ArmBindMode:
    """手臂绑定模式枚举."""
    ArmBindWithNull: int  # 无绑定
    LeftArmBindWithWaist: int  # 左臂与腰部绑定
    RightArmBindWithWaist: int  # 右臂与腰部绑定
    DoubleArmBindWithWaist: int  # 双臂与腰部绑定

class ModbusCommandType:
    """Modbus命令类型枚举."""
    CMD_READ_INPUT_REGISTER: int  # 读单个输入寄存器 (0x04)
    CMD_WRITE_MULTIPLE_REGISTERS: int  # 写多个寄存器 (0x10)

class ModbusRtuData:
    """Modbus RTU数据结构."""
    name: str  # 数据从"COM1"或"COM2"发出
    slaveid: int  # 从站ID
    addr: int  # 首个寄存器地址
    amount: int  # 数据长度 几个寄存器不是字节数
    write_value: int  # 写单个寄存器使用
    writeValues: "UInt16Vector"  # 写多个寄存器使用

class AxisParameterIndex:
    """轴参数索引枚举."""
    KPositiveLimitation: int  # 正向限位
    KNegtiveLimitation: int  # 负向限位

BatteryInfoVector = List[BatteryInfo]
Point3DVector = List[Point3D]
RobotWorldsDataVector = List[RobotWorldsData]

# 机械臂相关容器类型
Int32Vector = List[int]
IntDoubleVectorMap = Dict[int, DoubleVector]

# ================== Main SDK Class ==================

class PilotSDK:
    """
    Python wrapper around PilotSDK for AGV robot control.

    Provides comprehensive robot control functionality including connection
    management, status monitoring, action control, and data callbacks.
    """

    def __init__(self, robotHost: str = "127.0.0.1") -> None:
        """
        Initialize PilotSDK instance.

        Args:
            robotHost: Robot IP address, defaults to localhost
        """
        ...

    # ================== 初始化和连接管理 ==================

    def start(self, wsServerThreads: int = 1) -> bool:
        """
        Start SDK services.

        Args:
            wsServerThreads: Number of WebSocket server threads

        Returns:
            True if started successfully, False otherwise
        """
        ...

    def stop(self) -> None:
        """Stop SDK services."""
        ...

    def getConnectionStatus(self) -> str:
        """
        Get connection status as JSON string.

        Returns:
            JSON formatted connection status information
        """
        ...

    # ================== 任务信息相关 ==================

    def getTaskId(self) -> Tuple[int, str]:
        """
        Get current task ID.

        Returns:
            Tuple of (result_code, task_id)
        """
        ...

    def getTaskUpdateId(self) -> Tuple[int, int]:
        """
        Get task update ID.

        Returns:
            Tuple of (result_code, task_update_id)
        """
        ...

    # ================== 位置和路径信息 ==================

    def getLastNodeId(self) -> Tuple[int, str]:
        """
        Get last reached node ID.

        Returns:
            Tuple of (result_code, last_node_id)
        """
        ...

    def getLastNodeSequenceId(self) -> Tuple[int, int]:
        """
        Get last reached node sequence ID.

        Returns:
            Tuple of (result_code, last_node_sequence_id)
        """
        ...

    def getLastEdgeId(self) -> Tuple[int, str]:
        """
        Get last entered edge ID.

        Returns:
            Tuple of (result_code, last_edge_id)
        """
        ...

    def getDistanceSinceLastNode(self) -> Tuple[int, float]:
        """
        Get distance traveled since last node.

        Returns:
            Tuple of (result_code, distance_since_last_node)
        """
        ...

    # ================== 运行状态 ==================

    def getDriving(self) -> Tuple[int, bool]:
        """
        Get AGV driving status.

        Returns:
            Tuple of (result_code, is_driving)
        """
        ...

    def getAgvStatus(self) -> Tuple[int, str]:
        """
        Get AGV status.

        Returns:
            Tuple of (result_code, agv_status)
        """
        ...

    def getOperatingMode(self) -> Tuple[int, str]:
        """
        Get operating mode.

        Returns:
            Tuple of (result_code, operating_mode)
        """
        ...

    def getSoftStopSwitch(self) -> Tuple[int, str]:
        """
        Get soft stop switch status.

        Returns:
            Tuple of (result_code, soft_stop_switch)
        """
        ...

    def getController(self) -> Tuple[int, str]:
        """
        Get controller information.

        Returns:
            Tuple of (result_code, controller)
        """
        ...

    # ================== 核心状态信息 ==================

    def getAgvPosition(self) -> Tuple[int, Position]:
        """
        Get AGV position.

        Returns:
            Tuple of (result_code, position_data)
        """
        ...

    def getVelocity(self) -> Tuple[int, Velocity]:
        """
        Get AGV velocity.

        Returns:
            Tuple of (result_code, velocity_data)
        """
        ...

    def getMap(self) -> Tuple[int, MapInfo]:
        """
        Get map information.

        Returns:
            Tuple of (result_code, map_data)
        """
        ...

    # ================== 动作状态 ==================

    def getActionStates(self) -> Tuple[int, List[ActionState]]:
        """
        Get action states.

        Returns:
            Tuple of (result_code, action_states_list)
        """
        ...

    def getManualControlActions(self) -> Tuple[int, List[ManualControlAction]]:
        """
        Get manual control actions.

        Returns:
            Tuple of (result_code, manual_control_actions_list)
        """
        ...

    # ================== 负载和电池 ==================

    def getLoads(self) -> Tuple[int, List[LoadInfo]]:
        """
        Get load information.

        Returns:
            Tuple of (result_code, loads_list)
        """
        ...

    def getBatterys(self) -> Tuple[int, List[BatteryInfo]]:
        """
        Get battery information.

        Returns:
            Tuple of (result_code, batteries_list)
        """
        ...

    # ================== 硬件状态 ==================

    def getE84(self) -> Tuple[int, E84Info]:
        """
        Get E84 status.

        Returns:
            Tuple of (result_code, e84_info)
        """
        ...

    def getButtonStatus(self) -> Tuple[int, ButtonStatus]:
        """
        Get button status.

        Returns:
            Tuple of (result_code, button_status)
        """
        ...

    def getStorageDoors(self) -> Tuple[int, List[StorageDoorInfo]]:
        """
        Get storage door status.

        Returns:
            Tuple of (result_code, storage_doors_list)
        """
        ...

    def getNfcRingInfo(self) -> Tuple[int, NfcRingInfo]:
        """
        Get NFC ring information.

        Returns:
            Tuple of (result_code, nfc_ring_info)
        """
        ...

    # ================== 储位信息 ==================

    def getStorageStatusList(self) -> Tuple[int, List[StorageInfo]]:
        """
        Get storage status list.

        Returns:
            Tuple of (result_code, storage_status_list)
        """
        ...

    # ================== 扩展参数 ==================

    def getExtendedParameters(self) -> Tuple[int, List[Parameter]]:
        """
        Get extended parameters.

        Returns:
            Tuple of (result_code, extended_parameters_list)
        """
        ...

    # ================== 专属SDK接口 ==================

    def setAgvVelData(self, x: float, y: float, omega: float) -> int:
        """
        Set AGV velocity data.

        Args:
            x: X velocity
            y: Y velocity
            omega: Angular velocity

        Returns:
            Result code (0 for success)
        """
        ...

    def setsoftEStop(self, status: bool) -> int:
        """
        Set soft emergency stop status.

        Args:
            status: Emergency stop status

        Returns:
            Result code (0 for success)
        """
        ...

    # ================== 即时动作接口 ==================

    def reposition(self, x: float, y: float, theta: float, auto_mode: bool = False) -> int:
        """
        Reposition robot.

        Args:
            x: X coordinate
            y: Y coordinate
            theta: Angle in radians
            auto_mode: Auto reposition mode

        Returns:
            Result code (0 for success)
        """
        ...

    def enableMap(self, mapId: str) -> int:
        """
        Enable specified map.

        Args:
            mapId: Map ID

        Returns:
            Result code (0 for success)
        """
        ...

    def downloadMap(self, map_md5_infos: StringMap) -> int:
        """
        Download map with MD5 information.

        Args:
            map_md5_infos: Map MD5 information dictionary

        Returns:
            Result code (0 for success)
        """
        ...

    def vehicleRotation(self, theta: float, coordinate: str = "MAP") -> int:
        """
        Rotate vehicle.

        Args:
            theta: Target angle in radians
            coordinate: Coordinate system (ROBOT/MAP)

        Returns:
            Result code (0 for success)
        """
        ...

    def trayRotation(self, targetAngles: DoubleVector, speed: float, coordinate: str = "MAP") -> int:
        """
        Rotate tray.

        Args:
            targetAngles: Target angles list
            speed: Rotation speed
            coordinate: Coordinate system (ROBOT/MAP)

        Returns:
            Result code (0 for success)
        """
        ...

    def trayLifting(self, speed: float, targetTicks: int) -> int:
        """
        Lift tray.

        Args:
            speed: Lifting speed
            targetTicks: Target ticks

        Returns:
            Result code (0 for success)
        """
        ...

    def readVehicleRegister(self, code: int, slavedId: int, address: int) -> Tuple[int, int]:
        """
        Read vehicle register.

        Args:
            code: Register code
            slavedId: Slave ID
            address: Register address

        Returns:
            Tuple of (result_code, read_value)
        """
        ...

    def writeVehicleRegister(self, code: int, slavedId: int, address: int, value: int) -> int:
        """
        Write vehicle register.

        Args:
            code: Register code
            slavedId: Slave ID
            address: Register address
            value: Value to write

        Returns:
            Result code (0 for success)
        """
        ...

    def roboticArmControl(self, script: Dict[str, Any]) -> int:
        """
        Control robotic arm.

        Args:
            script: Robotic arm control script

        Returns:
            Result code (0 for success)
        """
        ...

    def charge(self, chargeMode: str, time: int, batteryLevel: int) -> int:
        """
        Control charging.

        Args:
            chargeMode: Charging mode
            time: Charging time
            batteryLevel: Battery level

        Returns:
            Result code (0 for success)
        """
        ...

    def accurateAdjust(self, featureType: str, x: float, y: float, theta: float,
                      qrAdjustAngleLimit: float, qrAdjustDistanceLimit: float,
                      dockID: int, objectId: int) -> int:
        """
        Perform accurate adjustment.

        Args:
            featureType: Feature type
            x: X coordinate
            y: Y coordinate
            theta: Angle
            qrAdjustAngleLimit: QR adjustment angle limit
            qrAdjustDistanceLimit: QR adjustment distance limit
            dockID: Dock ID
            objectId: Object ID

        Returns:
            Result code (0 for success)
        """
        ...

    def docking(self, featureType: str, isCharge: bool, x: float, y: float, theta: float,
               direction: str, dockID: int, objectId: int,
               cameraAvoidance: bool, start_x: float, start_y: float, start_theta: float,
               end_x: float, end_y: float, end_theta: float) -> int:
        """
        Perform docking operation.

        Args:
            featureType: Feature type
            isCharge: Whether charging dock
            x: X coordinate
            y: Y coordinate
            theta: Angle
            direction: Direction
            dockID: Dock ID
            objectId: Object ID
            cameraAvoidance: Camera avoidance
            start_x: Start X coordinate
            start_y: Start Y coordinate
            start_theta: Start angle
            end_x: End X coordinate
            end_y: End Y coordinate
            end_theta: End angle

        Returns:
            Result code (0 for success)

        Note:
            enableManualResetError 参数已删除 (2025/12/12)
        """
        ...

    def clearDockingError(self) -> int:
        """
        Clear docking error.

        Returns:
            Result code (0 for success)
        """
        ...

    def switchSpeedAvoidanceMode(self, speedMode: str) -> int:
        """
        Switch speed avoidance mode.

        Args:
            speedMode: Speed mode

        Returns:
            Result code (0 for success)
        """
        ...

    def switchAvoidanceFieldSet(self, fieldSet: int) -> int:
        """
        Switch avoidance field set.

        Args:
            fieldSet: Field set number

        Returns:
            Result code (0 for success)
        """
        ...

    # areaDetection 已根据新协议删除 (2025/12/11)

    def trayFollowControl(self, type: str) -> int:
        """
        Control tray following.

        Args:
            type: Follow type

        Returns:
            Result code (0 for success)
        """
        ...

    def audioPlay(self, playTrigger: str, audioName: str, audioVolume: int, playCount: int) -> int:
        """
        Play audio.

        Args:
            playTrigger: Play trigger
            audioName: Audio name
            audioVolume: Audio volume
            playCount: Play count

        Returns:
            Result code (0 for success)
        """
        ...

    def readQrCodeID(self) -> Tuple[int, QrInfo]:
        """
        Read QR code ID.

        Returns:
            Tuple of (result_code, qr_info)
        """
        ...

    def forkArmLifting(self, speed: float, possition: float) -> int:
        """
        Control fork arm lifting.

        Args:
            speed: Lifting speed
            possition: Target position

        Returns:
            Result code (0 for success)
        """
        ...

    def cancelTask(self) -> int:
        """
        Cancel current task.

        Returns:
            Result code (0 for success)
        """
        ...

    def pauseTask(self) -> int:
        """
        Pause current task.

        Returns:
            Result code (0 for success)
        """
        ...

    def restoreTask(self) -> int:
        """
        Restore paused task.

        Returns:
            Result code (0 for success)
        """
        ...

    def requestConnection(self, ip: str, port: str) -> int:
        """
        Request connection to robot with port.

        Args:
            ip: Robot IP address
            port: Robot port

        Returns:
            Result code (0 for success)
        """
        ...

    def requestConnection(self, ip: str) -> int:
        """
        Request connection to robot.

        Args:
            ip: Robot IP address

        Returns:
            Result code (0 for success)
        """
        ...

    def acquireControl(self) -> Tuple[int, str, str]:
        """
        Acquire robot control.

        Returns:
            Tuple of (result_code, token, vest)
        """
        ...

    def releaseControl(self) -> int:
        """
        Release robot control.

        Returns:
            Result code (0 for success)
        """
        ...

    def shutDown(self) -> int:
        """
        Shutdown robot.

        Returns:
            Result code (0 for success)
        """
        ...

    def reboot(self) -> int:
        """
        Reboot robot.

        Returns:
            Result code (0 for success)
        """
        ...

    def reset(self) -> int:
        """
        Reset robot.

        Returns:
            Result code (0 for success)
        """
        ...

    def manualSpeedControl(self, type: str, vx: float, vy: float, omega: float) -> int:
        """
        Manual speed control.

        Args:
            type: Control type (START/MOVE/END)
            vx: X velocity
            vy: Y velocity
            omega: Angular velocity

        Returns:
            Result code (0 for success)
        """
        ...

    def buildingMap(self, mapId: str, instruction: str) -> int:
        """
        Build map.

        Args:
            mapId: Map ID
            instruction: Building instruction

        Returns:
            Result code (0 for success)
        """
        ...

    def triggerTaskChain(
        self,
        taskChainId: str,
        loopCount: int = 1,
        variableMap: Optional[List[Dict[str, Any]]] = None,
    ) -> int:
        """
        Trigger task chain.

        Args:
            taskChainId: Task chain ID
            loopCount: Loop count (optional, default 1, -1 for infinite)
            variableMap: Variable map (optional), format: [{"key": str, "value": Any}, ...]

        Returns:
            Result code (0 for success)
        """
        ...

    def rcsConnectionManage(self, cmd: str) -> int:
        """
        Manage RCS connection.

        Args:
            cmd: Command string

        Returns:
            Result code (0 for success)
        """
        ...

    def storageDoorControl(self, id: str, action: str) -> int:
        """
        Control storage door.

        Args:
            id: Storage door ID (string)
            action: Action ("OPEN"/"CLOSE")

        Returns:
            Result code (0 for success)
        """
        ...

    def storageLockControl(self, storageId: str, timeout: int, action: str) -> int:
        """
        Control storage lock.

        Args:
            storageId: Storage ID (string)
            timeout: Timeout duration
            action: Lock action ("OPEN"/"CLOSE")

        Returns:
            Result code (0 for success)
        """
        ...

    def gratingControl(self, gratingId: str, action: str) -> int:
        """
        Control grating.

        Args:
            gratingId: Grating ID (string)
            action: Action ("OPEN"/"CLOSE")

        Returns:
            Result code (0 for success)
        """
        ...

    def dustParticleDetector(self, action: str) -> int:
        """
        Control dust particle detector.

        Args:
            action: Action ("OPEN"/"CLOSE")

        Returns:
            Result code (0 for success)
        """
        ...

    def resetFFU(self) -> int:
        """
        Reset FFU.

        Returns:
            Result code (0 for success)
        """
        ...

    def FFUControl(self, action: str) -> int:
        """
        Control FFU.

        Args:
            action: Action ("OPEN"/"CLOSE")

        Returns:
            Result code (0 for success)
        """
        ...

    def setWindSpeedFFU(self, speed: int) -> int:
        """
        Set FFU wind speed.

        Args:
            speed: Wind speed

        Returns:
            Result code (0 for success)
        """
        ...

    def resetE84(self) -> int:
        """
        Reset E84.

        Returns:
            Result code (0 for success)
        """
        ...

    def ioControlE84(self, outputNum: int, value: bool) -> int:
        """
        Control E84 I/O.

        Args:
            outputNum: Output number
            value: Output value (True/False)

        Returns:
            Result code (0 for success)
        """
        ...

    def openE84(self, side: int) -> int:
        """
        Open E84 sensor.

        Args:
            side: Side (0: left/front, 1: right/back)

        Returns:
            Result code (0 for success)
        """
        ...

    def dockE84(self, storageId: str, port: int) -> int:
        """
        Dock E84.

        Args:
            storageId: Storage ID (string)
            port: Port (1-7)

        Returns:
            Result code (0 for success)
        """
        ...

    def monitoringManualRelease(self, isOpen: bool) -> int:
        """
        Monitor manual release.

        Args:
            isOpen: Is open

        Returns:
            Result code (0 for success)
        """
        ...

    def storageScreenInfoUpdate(self, id: str, status: str) -> int:
        """
        Update storage screen information.

        Args:
            id: Storage ID
            status: Status

        Returns:
            Result code (0 for success)
        """
        ...

    def deviceCheckMode(self, device: str, mode: str) -> int:
        """
        Set device check mode.

        Args:
            device: Device name
            mode: Check mode ("OPEN"/"CLOSE")

        Returns:
            Result code (0 for success)
        """
        ...

    # ================== 新增即时动作 (V5.0 协议更新) ==================

    def readExternalRegister(self, ip: str, port: int, code: int, slaveId: int, address: int) -> Tuple[int, int]:
        """
        Read external register.

        Args:
            ip: IP address
            port: Port number
            code: Register code
            slaveId: Slave ID
            address: Register address

        Returns:
            Tuple of (result_code, read_value)
        """
        ...

    def writeExternalRegister(self, ip: str, port: int, code: int, slaveId: int, address: int, value: int) -> int:
        """
        Write external register.

        Args:
            ip: IP address
            port: Port number
            code: Register code
            slaveId: Slave ID
            address: Register address
            value: Value to write

        Returns:
            Result code (0 for success)
        """
        ...

    def checkExternalRegister(self, ip: str, port: int, code: int, slaveId: int, address: int,
        normalExit: int, failedExit: int = -1, timeout: int = -1) -> Tuple[int, bool]:
        """
        Check external register.

        Args:
            ip: IP address
            port: Port number
            code: Register code
            slaveId: Slave ID
            address: Register address
            normalExit: Normal exit value
            failedExit: Failed exit value (optional)
            timeout: Timeout (optional)

        Returns:
            Tuple of (result_code, check_result)
        """
        ...

    def softStop(self, operate: bool) -> int:
        """
        Soft stop control.

        Args:
            operate: Operation (True for emergency stop, False for release)

        Returns:
            Result code (0 for success)
        """
        ...

    def reloadTaskChainFolder(self) -> int:
        """
        Reload task chain folder.

        Returns:
            Result code (0 for success)
        """
        ...

    def switchOperationMode(self, mode: str) -> int:
        """
        Switch operation mode.

        Args:
            mode: Operation mode (AUTO/MANUAL/SERVICE)

        Returns:
            Result code (0 for success)
        """
        ...

    # ================== 回调函数接口 ==================

    def cancelCallback(self, data_type: str) -> bool:
        """
        Cancel generic callback.

        Args:
            data_type: Data type identifier

        Returns:
            True if cancelled successfully
        """
        ...

    def cancelLidarDataCallback(self, lidar_id: int) -> bool:
        """
        Cancel lidar data callback.

        Args:
            lidar_id: Lidar ID

        Returns:
            True if cancelled successfully
        """
        ...

    def cancelImuCallback(self) -> bool:
        """
        Cancel IMU callback.

        Returns:
            True if cancelled successfully
        """
        ...

    def cancelOdomCallback(self) -> bool:
        """
        Cancel odometry callback.

        Returns:
            True if cancelled successfully
        """
        ...

    def cancelVelocityCallback(self) -> bool:
        """
        Cancel velocity callback.

        Returns:
            True if cancelled successfully
        """
        ...

    def cancelCurrentPoseCallback(self) -> bool:
        """
        Cancel current pose callback.

        Returns:
            True if cancelled successfully
        """
        ...

    def cancelQrDataCallback(self, qr_id: int) -> bool:
        """
        Cancel QR data callback.

        Args:
            qr_id: QR camera ID

        Returns:
            True if cancelled successfully
        """
        ...

    def cancelCameraCallback(self, camera_id: int) -> bool:
        """
        Cancel camera callback.

        Args:
            camera_id: Camera ID

        Returns:
            True if cancelled successfully
        """
        ...

    def setImuCallback(self, py_func: ImuCallback) -> bool:
        """
        Set IMU data callback.

        Args:
            py_func: Callback function receiving ImuData

        Returns:
            True if set successfully
        """
        ...

    def setOdomCallback(self, py_func: OdomCallback) -> bool:
        """
        Set odometry data callback.

        Args:
            py_func: Callback function receiving OdomData

        Returns:
            True if set successfully
        """
        ...

    def setVelocityCallback(self, py_func: VelocityCallback) -> bool:
        """
        Set velocity data callback.

        Args:
            py_func: Callback function receiving VelocityData

        Returns:
            True if set successfully
        """
        ...

    def setCurrentPoseCallback(self, py_func: CurrentPoseCallback) -> bool:
        """
        Set current pose callback.

        Args:
            py_func: Callback function receiving CurrentPoseData

        Returns:
            True if set successfully
        """
        ...

    def setQrDataCallback(self, qr_id: int, py_func: QrDataCallback) -> bool:
        """
        Set QR data callback.

        Args:
            qr_id: QR camera ID
            py_func: Callback function receiving QrData

        Returns:
            True if set successfully
        """
        ...

    def setCameraCallback(self, camera_id: int, py_func: CameraCallback) -> bool:
        """
        Set camera data callback.

        Args:
            camera_id: Camera ID
            py_func: Callback function receiving CameraData

        Returns:
            True if set successfully
        """
        ...

    def setLidarDataCallback(self, lidar_id: int, py_func: LidarCallback) -> bool:
        """
        Set lidar data callback.

        Args:
            lidar_id: Lidar ID
            py_func: Callback function receiving LidarData

        Returns:
            True if set successfully
        """
        ...

    # ================== 查询接口 ==================

    def queryAgvInfo(self) -> Tuple[int, AgvInfo]:
        """
        Query AGV basic information.

        Returns:
            Tuple of (result_code, agv_info)
        """
        ...

    def queryDatabaseParameter(self, paramName: str) -> Tuple[int, str]:
        """
        Query database parameter.

        Args:
            paramName: Parameter name

        Returns:
            Tuple of (result_code, parameter_value)
        """
        ...

    def queryIndustrialPcInfo(self) -> Tuple[int, ComputerInfo]:
        """
        Query industrial PC information.

        Returns:
            Tuple of (result_code, computer_info)
        """
        ...

    def queryVibrationValue(self) -> Tuple[int, float]:
        """
        Query vibration value.

        Returns:
            Tuple of (result_code, vibration_value)
        """
        ...

    def queryFFUconfig(self) -> Tuple[int, float, float]:
        """
        Query FFU configuration.

        Returns:
            Tuple of (result_code, capture_velocity, detection_threshold)
        """
        ...

    def queryLaserData(self) -> Tuple[int, LaserData2D]:
        """
        Query laser data.

        Returns:
            Tuple of (result_code, laser_data)
        """
        ...

    # ================== 机械臂接口 ==================

    # 基础函数
    def armInitData(self, local_ip: str, arm_ip: str, port: int) -> int:
        """初始化机械臂数据连接."""
        ...

    def armGetLinkStatus(self) -> Tuple[int, bool]:
        """获取连接状态."""
        ...

    def armDetachHMI(self) -> int:
        """分离HMI."""
        ...

    def armGetDetachHMIStatus(self) -> Tuple[int, bool]:
        """获取HMI分离状态."""
        ...

    def armServoIsOpOrNot(self) -> Tuple[int, bool]:
        """检查伺服是否运行."""
        ...

    def armIsAlarming(self) -> Tuple[int, StringVector, bool]:
        """检查是否报警."""
        ...

    def armClearAlarm(self) -> int:
        """清除报警."""
        ...

    def armRobotEnableOrNot(self, enable: bool) -> int:
        """启用/禁用机器人."""
        ...

    def armGetRobotEnableStatus(self) -> Tuple[int, bool]:
        """获取机器人启用状态."""
        ...

    def armSetSingleRobotEnable(self, robotId: int, enable: bool) -> int:
        """设置单个机器人启用状态."""
        ...

    def armGetSingleRobotEnableStatus(self, robotId: int) -> Tuple[int, bool]:
        """获取单个机器人启用状态."""
        ...

    def armSetGlobalSpeed(self, speed: float) -> int:
        """设置全局速度."""
        ...

    def armGetGlobalSpeed(self) -> Tuple[int, float]:
        """获取全局速度."""
        ...

    def armSetRobotAlarmNotServoOff(self, needNotOff: bool) -> int:
        """设置报警时是否关闭伺服."""
        ...

    def armGetRobotAlarmNotServoOff(self) -> Tuple[int, bool]:
        """获取报警时是否关闭伺服设置."""
        ...

    def armSetRobotProtectStatus(self, robotId: int, protect: bool) -> int:
        """设置机器人保护状态."""
        ...

    def armGetRobotProtectStatus(self, robotId: int) -> Tuple[int, bool]:
        """获取机器人保护状态."""
        ...

    def armSetAlarmNotPrompt(self, flag: int) -> int:
        """设置告警不提示."""
        ...

    def armGetAlarmNotPrompt(self) -> Tuple[int, int]:
        """获取告警不提示."""
        ...

    # 运动函数
    def armMoveWorlds(self, robotId: int, worlds: FloatVector,
                      interpolation_en: bool = False, needCallback: bool = False,
                      delay_in_ms: int = 0) -> int:
        """世界坐标运动."""
        ...

    def armMoveWorldsCurve(self, robotId: int, midWorld: FloatVector,
                           endWorld: FloatVector, needCallback: bool = False,
                           delay_in_ms: int = 0) -> int:
        """曲线运动."""
        ...

    def armMoveWorldsRound(self, robotId: int, midWorld: FloatVector,
                           endWorld: FloatVector, needCallback: bool = False,
                           delay_in_ms: int = 0) -> int:
        """圆周运动."""
        ...

    def armMoveJoints(self, robotId: int, joints: FloatVector,
                      needCallback: bool = False, delay_in_ms: int = 0) -> int:
        """关节运动."""
        ...

    def armPluseToServo(self, robotId: int, joints: FloatVector) -> int:
        """脉冲转伺服."""
        ...

    def armWorldsToServo(self, robotId: int, worlds: FloatVector) -> int:
        """世界坐标转伺服."""
        ...

    def armGetJoints(self, robotId: int, fb: bool = True) -> Tuple[int, FloatVector]:
        """获取关节角度. 与 pypilot.cpp 一致: (result_code, joints)."""
        ...

    def armGetWorlds(self, robotId: int, fb: bool = True) -> Tuple[int, FloatVector]:
        """获取世界坐标. 与 pypilot.cpp 一致: (result_code, worlds)."""
        ...

    def armGetVelocity(self, robotId: int) -> Tuple[int, float]:
        """获取速度."""
        ...

    def armGetAcceleration(self, robotId: int) -> Tuple[int, float]:
        """获取加速度."""
        ...

    def armSwitchRunMode(self, robotId: int, mode: int, axis: int = -1) -> int:
        """切换运行模式."""
        ...

    def armGetCurrentRunMode(self, robotId: int, axis: int) -> Tuple[int, int]:
        """获取当前运行模式."""
        ...

    def armGetPulseFeedback(self, robotId: int, axisId: int) -> Tuple[int, int]:
        """获取脉冲反馈."""
        ...

    def armGetTorqueFeedbackVector(self, robotId: int) -> Tuple[int, Int32Vector]:
        """获取转矩反馈向量. 与 pypilot.cpp 一致: (result_code, torque_feedback)."""
        ...

    def armGetSpeedFeedback(self, robotId: int) -> Tuple[int, Int32Vector]:
        """获取速度反馈. 与 pypilot.cpp 一致: (result_code, speed_feedback)."""
        ...

    def armTorqueToServo(self, robotId: int, torques: Int32Vector) -> int:
        """转矩转伺服."""
        ...

    def armSpeedToServo(self, robotId: int, speeds: Int32Vector) -> int:
        """速度转伺服."""
        ...

    def armPauseRobot(self, robotId: int, pause: bool) -> int:
        """暂停/恢复机器人."""
        ...

    def armClearRobotRoute(self, robotId: int, emergency_stop: bool = True) -> int:
        """清除机器人路径."""
        ...

    def armGetRobotPaused(self, robotId: int) -> Tuple[int, bool]:
        """获取机器人暂停状态."""
        ...

    def armSetEnableTolerance(self, robot_id: int, enable: bool,
                             tolerance: float = 0.1, tolerance_time: float = 0.5) -> Tuple[int, bool]:
        """启用容差."""
        ...

    def armGetRobotMoveState(self, robot_id: int) -> Tuple[int, int]:
        """获取机器人运动状态."""
        ...

    def armGetRobotAxisMoveState(self, robot_id: int, axis_id: int) -> Tuple[int, int]:
        """获取机器人轴运动状态."""
        ...

    def armGetAxisParameter(self, robot_id: int, axis_id: int,
                            index: int) -> Tuple[int, float]:
        """获取轴参数."""
        ...

    def armSetAxisParameter(self, robot_id: int, axis_id: int,
                            index: int, limitation: float) -> int:
        """设置轴参数."""
        ...

    def armTryWorlds(self, robotId: int, worlds: DoubleVector) -> Tuple[int, DoubleVector]:
        """尝试世界坐标."""
        ...

    def armJointOutLimit(self, robotId: int, axis_id: int,
                         joint: float) -> Tuple[int, bool, bool, bool]:
        """检查关节是否超限."""
        ...

    # 力控函数
    def armActivateDragTeach(self, robot_id: int, sw: bool,
                             friction: DoubleVector = [], compensate: DoubleVector = []) -> int:
        """激活拖拽示教."""
        ...

    def armActivateCollision(self, robot_id: int, sw: bool,
                             threshold: IntVector) -> Tuple[int, bool]:
        """激活碰撞检测."""
        ...

    def armSetLoadParam(self, parameter: LoadParameter) -> Tuple[int, int]:
        """设置负载参数."""
        ...

    def armGetLoadParam(self, load_id: int) -> Tuple[int, LoadParameter, bool]:
        """获取负载参数."""
        ...

    def armSetRobotLoad(self, load_id: int, robot_id: int) -> Tuple[int, bool]:
        """设置机器人负载."""
        ...

    def armForceKeepSwitch(self, robotId: int, state: int, type: int = -1,
                           fm: float = -1, startPos: DoubleVector = [],
                           adm_param: DoubleVector = []) -> int:
        """力保持开关."""
        ...

    def armGetForceKeepState(self, robotId: int) -> Tuple[int, int]:
        """获取力保持状态."""
        ...

    def armGetTorqueFeedbackSingle(self, robotId: int, axisId: int) -> Tuple[int, int]:
        """获取单个轴转矩反馈."""
        ...

    def armAdmittanceControlInit(self, robotId: int,
                                 adm_param_6dof: IntDoubleVectorMap) -> int:
        """初始化导纳控制."""
        ...

    def armAdmittanceControl(self, robotId: int, forces: DoubleVector) -> int:
        """导纳控制."""
        ...

    def armOpenCom(self, com: str, baudrate: int = 115200, databits: int = 8, parity: int = 0, stopbits: int = 1) -> int:
        """打开串口."""
        ...

    def armWriteCom(self, com: str, buffer: str) -> int:
        """写串口."""
        ...

    def armReadCom(self, com: str, buffer_len: int) -> Tuple[int, str]:
        """读串口."""
        ...

    def armModbusControl(self, cmd: int, modbusData: "ModbusRtuData") -> int:
        """Modbus控制."""
        ...

    # 自定义函数
    def armSetWaistSafePose(self, angle: float) -> int:
        """设置腰部安全姿态."""
        ...

    def armGetWaistSafePose(self) -> Tuple[int, float]:
        """获取腰部安全姿态."""
        ...

    def armGetArmBindMode(self) -> Tuple[int, int, bool]:
        """获取手臂绑定模式."""
        ...

    def armBindModeWorldMove(self, mode: int,
                             robotWorlds: RobotWorldsDataVector) -> int:
        """绑定模式世界坐标运动."""
        ...

    # 机械臂回调函数
    def armSetMoveJointsEndCallback(self, py_func: MoveJointsEndCallback) -> int:
        """设置关节运动结束回调."""
        ...

    def armCancelMoveJointsEndCallback(self) -> int:
        """取消关节运动结束回调."""
        ...

    def armSetMoveWorldsEndCallback(self, py_func: MoveWorldsEndCallback) -> int:
        """设置世界坐标运动结束回调."""
        ...

    def armCancelMoveWorldsEndCallback(self) -> int:
        """取消世界坐标运动结束回调."""
        ...

# ================== Vector Types ==================

class FloatVector:
    """Float vector type for passing arrays between Python and C++."""
    def __init__(self) -> None: ...
    def append(self, value: float) -> None: ...
    def extend(self, values: List[float]) -> None: ...
    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> float: ...
    def __setitem__(self, index: int, value: float) -> None: ...
    def __iter__(self): ...

class DoubleVector:
    """Double vector type for passing arrays between Python and C++."""
    def __init__(self) -> None: ...
    def append(self, value: float) -> None: ...
    def extend(self, values: List[float]) -> None: ...
    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> float: ...
    def __setitem__(self, index: int, value: float) -> None: ...
    def __iter__(self): ...

class IntVector:
    """Integer vector type for passing arrays between Python and C++."""
    def __init__(self) -> None: ...
    def append(self, value: int) -> None: ...
    def extend(self, values: List[int]) -> None: ...
    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> int: ...
    def __setitem__(self, index: int, value: int) -> None: ...
    def __iter__(self): ...

class StringVector:
    """String vector type for passing string arrays between Python and C++."""
    def __init__(self) -> None: ...
    def append(self, value: str) -> None: ...
    def extend(self, values: List[str]) -> None: ...
    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> str: ...
    def __setitem__(self, index: int, value: str) -> None: ...
    def __iter__(self): ...

class BoolVector:
    """Boolean vector type for passing boolean arrays between Python and C++."""
    def __init__(self) -> None: ...
    def append(self, value: bool) -> None: ...
    def extend(self, values: List[bool]) -> None: ...
    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> bool: ...
    def __setitem__(self, index: int, value: bool) -> None: ...
    def __iter__(self): ...

class StringMap:
    """String map type for passing dictionaries between Python and C++."""
    def __init__(self) -> None: ...
    def __setitem__(self, key: str, value: str) -> None: ...
    def __getitem__(self, key: str) -> str: ...
    def __contains__(self, key: str) -> bool: ...
    def __len__(self) -> int: ...
    def __iter__(self): ...

class Int32Vector:
    """Int32 vector type for passing int32_t arrays between Python and C++."""
    def __init__(self) -> None: ...
    def append(self, value: int) -> None: ...
    def extend(self, values: List[int]) -> None: ...
    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> int: ...
    def __setitem__(self, index: int, value: int) -> None: ...
    def __iter__(self): ...

class UInt16Vector:
    """UInt16 vector type for passing uint16_t arrays between Python and C++."""
    def __init__(self) -> None: ...
    def append(self, value: int) -> None: ...
    def extend(self, values: List[int]) -> None: ...
    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> int: ...
    def __setitem__(self, index: int, value: int) -> None: ...
    def __iter__(self): ...

class IntDoubleVectorMap:
    """Map type for passing int to double vector dictionaries between Python and C++."""
    def __init__(self) -> None: ...
    def __setitem__(self, key: int, value: DoubleVector) -> None: ...
    def __getitem__(self, key: int) -> DoubleVector: ...
    def __contains__(self, key: int) -> bool: ...
    def __len__(self) -> int: ...
    def __iter__(self): ...

# ================== Factory Functions ==================

def create_sdk() -> PilotSDK:
    """
    创建并返回一个PilotSDK实例.
    
    Returns:
        PilotSDK: 新的SDK实例
    
    Example:
        >>> import pypilot
        >>> sdk = pypilot.create_sdk()
        >>> # 或者直接使用
        >>> sdk = pypilot.PilotSDK()
    """
    ...

# ================== Module Exports ==================

__all__ = [
    # 主SDK类
    'PilotSDK',
    'create_sdk',
    # 基础数据类型
    'Position',
    'Velocity',
    'MapInfo',
    'ActionState',
    'ManualControlAction',
    'BatteryInfo',
    'LoadInfo',
    'LoadDimensions',
    'StorageInfo',
    'E84Info',
    'ButtonStatus',
    'StorageDoorInfo',
    'NfcRingInfo',
    'ErrorInfo',
    'RasterInfo',
    'FFUInfo',
    'DustParticleDetectorInfo',
    'Parameter',
    'QrInfo',
    'AgvInfo',
    'ComputerInfo',
    # 几何数据类型
    'Point2D',
    'Point3D',
    # 传感器数据类型
    'LaserData2D',
    'LidarData',
    'ImuData',
    'OdomData',
    'VelocityData',
    'CurrentPoseData',
    'QrData',
    'CameraData',
    # 容器类型
    'FloatVector',
    'DoubleVector',
    'IntVector',
    'StringVector',
    'BoolVector',
    'StringMap',
    'BatteryInfoVector',
    'Point3DVector',
    # 回调函数类型
    'ImuCallback',
    'OdomCallback',
    'VelocityCallback',
    'CurrentPoseCallback',
    'QrDataCallback',
    'CameraCallback',
    'LidarCallback',
    # 机械臂相关
    'MoveJointsEndData',
    'MoveWorldsEndData',
    'LoadParameter',
    'RobotWorldsData',
    'MoveJointsEndCallback',
    'MoveWorldsEndCallback',
    'Int32Vector',
    'RobotWorldsDataVector',
    'IntDoubleVectorMap',
    'ArmBindMode',
    'AxisParameterIndex'
]

# Version information
__version__: str = "1.0.0"
__author__: str = "YouiPilot SDK Team"