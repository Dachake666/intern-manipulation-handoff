"""
依赖库加载脚本
使用 ctypes 预加载必要的动态链接库
"""
import os
import sys
import ctypes
import glob

def preload_libraries():
    """预加载所有必要的动态链接库"""
    # 获取模块所在目录
    module_dir = os.path.dirname(os.path.abspath(__file__))
    libs_dir = os.path.join(module_dir, '.libs')

    if not os.path.exists(libs_dir):
        return False

    # 公共库使用 RTLD_GLOBAL 模式
    preload_global = [
        'libssl.so',
        'libcrypto.so',
        'libyouizmq.so',
    ]
    
    # libxoip.so 使用 RTLD_LOCAL 模式，避免与 pypilot.so 中的 httplib 符号冲突
    preload_local = [
        'libxoip.so',
    ]

    loaded_libs = []

    try:
        # 设置库路径
        if hasattr(os, 'add_dll_directory'):
            # Windows
            os.add_dll_directory(libs_dir)
        else:
            # Linux/macOS - 设置RPATH fallback
            if 'LD_LIBRARY_PATH' in os.environ:
                os.environ['LD_LIBRARY_PATH'] = libs_dir + ':' + os.environ['LD_LIBRARY_PATH']
            else:
                os.environ['LD_LIBRARY_PATH'] = libs_dir

        # 使用RTLD_GLOBAL模式加载公共库
        for lib_name in preload_global:
            lib_path = os.path.join(libs_dir, lib_name)
            if os.path.exists(lib_path):
                try:
                    ctypes.CDLL(lib_path, mode=ctypes.RTLD_GLOBAL)
                    loaded_libs.append(lib_name)
                    print(f"✓ 预加载库: {lib_name}")
                except Exception as e:
                    print(f"✗ 预加载库失败 {lib_name}: {e}")
                    return False
            else:
                pattern = os.path.join(libs_dir, lib_name.replace('.so', '*.so'))
                matches = glob.glob(pattern)
                if matches:
                    lib_path = matches[0]
                    try:
                        ctypes.CDLL(lib_path, mode=ctypes.RTLD_GLOBAL)
                        loaded_libs.append(os.path.basename(lib_path))
                        print(f"✓ 预加载库: {os.path.basename(lib_path)}")
                    except Exception as e:
                        print(f"✗ 预加载库失败 {os.path.basename(lib_path)}: {e}")
                        return False

        # 使用RTLD_LOCAL模式加载可能有符号冲突的库
        for lib_name in preload_local:
            lib_path = os.path.join(libs_dir, lib_name)
            if os.path.exists(lib_path):
                try:
                    # 使用 RTLD_LOCAL 模式，不暴露符号到全局空间
                    ctypes.CDLL(lib_path, mode=ctypes.RTLD_LOCAL)
                    loaded_libs.append(lib_name)
                    print(f"✓ 预加载库 (LOCAL): {lib_name}")
                except Exception as e:
                    print(f"✗ 预加载库失败 {lib_name}: {e}")
                    # libxoip 加载失败不是致命错误
                    pass

        return len(loaded_libs) > 0

    except Exception as e:
        print(f"预加载依赖库时出错: {e}")
        return False

# 执行预加载
_preload_success = preload_libraries()
if not _preload_success:
    print("警告: 依赖库预加载失败，可能导致后续导入错误")
